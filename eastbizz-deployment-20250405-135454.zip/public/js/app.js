// Redirect to real JS file
(function() {
    const script = document.createElement('script');
    script.src = '/build/assets/app-DCvLw1yW.js';
    document.head.appendChild(script);
    console.log('JS asset loader executed from /js/app.js');
})();
