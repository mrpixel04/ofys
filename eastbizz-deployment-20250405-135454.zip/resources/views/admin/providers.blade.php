<x-admin-layout>
    <livewire:admin.providers-list />
</x-admin-layout>
