<x-app-layout>
    <h1>Test</h1>
</x-app-layout>