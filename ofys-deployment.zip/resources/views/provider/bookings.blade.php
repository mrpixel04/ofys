@extends('layouts.provider.app')

@section('header', 'Bookings Management')

@section('content')
    @livewire('provider.manage-bookings')
@endsection
