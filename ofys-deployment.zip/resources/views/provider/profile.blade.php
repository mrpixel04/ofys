@extends('layouts.provider.app')

@section('content')
    <livewire:provider.profile />
@endsection
