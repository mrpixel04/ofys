<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="mb-8">
                <a href="<?php echo e(route('activities.show', $activity->id)); ?>" class="flex items-center text-yellow-500 hover:text-yellow-600">
                    <svg class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                    </svg>
                    Back to activity details
                </a>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h1 class="text-2xl font-semibold text-gray-900 mb-6">Book <?php echo e($activity->name); ?></h1>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Booking Form -->
                        <div class="md:col-span-2">
                            <form action="<?php echo e(route('customer.bookings.store', $activity->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <!-- Date & Time Selection -->
                                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                                    <h2 class="text-lg font-medium text-gray-900 mb-4">Select Date & Time</h2>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div>
                                            <label for="booking_date" class="block text-sm font-medium text-gray-700">Date</label>
                                            <div class="mt-1 w-full">
                                                <input type="date" name="booking_date" id="booking_date" min="<?php echo e(date('Y-m-d')); ?>" required
                                                    class="w-full h-10 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm">
                                            </div>
                                            <?php $__errorArgs = ['booking_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div>
                                            <label for="start_time" class="block text-sm font-medium text-gray-700">Start Time</label>
                                            <div class="mt-1 w-full">
                                                <select name="start_time" id="start_time" required
                                                    class="w-full h-10 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm">
                                                    <option value="">Select a time</option>
                                                    <?php for($hour = 8; $hour <= 17; $hour++): ?>
                                                        <option value="<?php echo e(sprintf('%02d', $hour)); ?>:00"><?php echo e(sprintf('%02d', $hour)); ?>:00</option>
                                                        <?php if($hour < 17): ?>
                                                            <option value="<?php echo e(sprintf('%02d', $hour)); ?>:30"><?php echo e(sprintf('%02d', $hour)); ?>:30</option>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Lot Selection for Camping/Glamping -->
                                <?php if(in_array($activity->activity_type, ['camping', 'glamping'])): ?>
                                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                                    <h2 class="text-lg font-medium text-gray-900 mb-4">Select Camping Lot</h2>

                                    <?php if($activity->lots->count() > 0): ?>
                                        <div class="grid grid-cols-1 gap-4">
                                            <?php $__currentLoopData = $activity->lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="border rounded-md p-4 <?php echo e($lot->is_available ? 'bg-white' : 'bg-gray-100'); ?>">
                                                    <div class="flex justify-between items-start">
                                                        <div class="flex items-start space-x-3">
                                                            <?php if($lot->is_available): ?>
                                                            <input type="radio" name="lot_id" id="lot_<?php echo e($lot->id); ?>" value="<?php echo e($lot->id); ?>"
                                                                   class="mt-1 focus:ring-yellow-500 h-4 w-4 text-yellow-500 border-gray-300"
                                                                   <?php echo e($loop->first && $lot->is_available ? 'checked' : ''); ?>

                                                                   <?php echo e(!$lot->is_available ? 'disabled' : ''); ?>>
                                                            <?php endif; ?>
                                                            <div>
                                                                <label for="lot_<?php echo e($lot->id); ?>" class="block text-sm font-medium text-gray-900">
                                                                    Lot <?php echo e($lot->id); ?> <?php echo e($lot->name ? '- ' . $lot->name : ''); ?>

                                                                </label>
                                                                <?php if($lot->description): ?>
                                                                    <p class="text-sm text-gray-500"><?php echo e($lot->description); ?></p>
                                                                <?php endif; ?>
                                                                <p class="text-sm text-gray-500">Capacity: <?php echo e($lot->capacity); ?>

                                                                    <?php echo e($lot->capacity == 1 ? 'person' : 'people'); ?></p>
                                                            </div>
                                                        </div>
                                                        <span class="inline-flex items-center <?php echo e($lot->is_available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?> px-2.5 py-0.5 rounded-full text-xs font-medium">
                                                            <?php echo e($lot->is_available ? 'Available' : 'Booked'); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php $__errorArgs = ['lot_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo e($errors->first('lot_id')); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php else: ?>
                                        <p class="text-sm text-gray-500 italic">No camping lots are available for this activity. Please contact the provider.</p>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>

                                <!-- Participant Information -->
                                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                                    <h2 class="text-lg font-medium text-gray-900 mb-4">Participants</h2>

                                    <div>
                                        <label for="participants" class="block text-sm font-medium text-gray-700">Number of Participants</label>
                                        <div class="mt-1 w-full">
                                            <select name="participants" id="participants" required
                                                class="w-full h-10 px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm">
                                                <?php for($i = $activity->min_participants; $i <= $activity->max_participants; $i++): ?>
                                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e($i === 1 ? 'person' : 'people'); ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['participants'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Special Requests -->
                                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                                    <h2 class="text-lg font-medium text-gray-900 mb-4">Special Requests</h2>

                                    <div>
                                        <label for="special_requests" class="block text-sm font-medium text-gray-700">Any special requests or requirements?</label>
                                        <div class="mt-1 w-full">
                                            <textarea name="special_requests" id="special_requests" rows="3"
                                                class="w-full px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm"
                                                placeholder="E.g., food allergies, accessibility needs, etc."></textarea>
                                        </div>
                                        <?php $__errorArgs = ['special_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="flex justify-end">
                                    <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-yellow-500 hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
                                        Continue to Payment
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- Booking Summary -->
                        <div class="md:col-span-1">
                            <div class="bg-gray-50 rounded-lg p-6 sticky top-6">
                                <h2 class="text-lg font-medium text-gray-900 mb-4">Booking Summary</h2>

                                <div class="mb-4">
                                    <div class="aspect-w-16 aspect-h-9 mb-4">
                                        <?php if($activity->images && is_array($activity->images) && count($activity->images) > 0): ?>
                                            <img src="<?php echo e(asset('storage/' . $activity->images[0])); ?>"
                                                alt="<?php echo e($activity->name); ?>"
                                                class="object-cover rounded-lg">
                                        <?php else: ?>
                                            <img src="https://via.placeholder.com/300x200?text=No+Image"
                                                alt="No image available"
                                                class="object-cover rounded-lg">
                                        <?php endif; ?>
                                    </div>

                                    <h3 class="text-base font-medium text-gray-900"><?php echo e($activity->name); ?></h3>
                                    <p class="text-sm text-gray-500"><?php echo e($activity->location); ?></p>
                                </div>

                                <div class="border-t border-gray-200 py-4">
                                    <dl class="space-y-2">
                                        <div class="flex justify-between">
                                            <dt class="text-sm text-gray-600">Price</dt>
                                            <dd class="text-sm font-medium text-gray-900">
                                                RM<?php echo e(number_format($activity->price, 2)); ?> / <?php echo e($activity->getPriceTypeFormattedAttribute()); ?>

                                            </dd>
                                        </div>

                                        <div class="flex justify-between">
                                            <dt class="text-sm text-gray-600">Duration</dt>
                                            <dd class="text-sm font-medium text-gray-900">
                                                <?php echo e(floor($activity->duration_minutes / 60)); ?> hrs <?php echo e($activity->duration_minutes % 60); ?> mins
                                            </dd>
                                        </div>

                                        <?php if($activity->includes_gear): ?>
                                            <div class="flex justify-between">
                                                <dt class="text-sm text-gray-600">Equipment</dt>
                                                <dd class="text-sm font-medium text-gray-900">Included</dd>
                                            </div>
                                        <?php endif; ?>
                                    </dl>
                                </div>

                                <div class="border-t border-gray-200 pt-4">
                                    <div class="flex justify-between font-medium">
                                        <dt class="text-base text-gray-900">Total</dt>
                                        <dd class="text-base text-gray-900" id="total-price">
                                            RM<?php echo e(number_format($activity->price, 2)); ?>

                                        </dd>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-1">
                                        Final price will be calculated based on number of participants
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const participantsSelect = document.getElementById('participants');
            const totalPriceElement = document.getElementById('total-price');
            const basePrice = <?php echo e($activity->price); ?>;
            const priceType = '<?php echo e($activity->price_type); ?>';

            // Update total price when number of participants changes
            if (participantsSelect && totalPriceElement) {
                participantsSelect.addEventListener('change', function() {
                    let total = basePrice;

                    // If price is per person, multiply by number of participants
                    if (priceType === 'per_person') {
                        total = basePrice * parseInt(this.value);
                    }

                    // Update the display
                    totalPriceElement.textContent = 'RM' + total.toFixed(2);
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH /Users/mrpixel/Documents/web/ofys/resources/views/customer/bookings/create.blade.php ENDPATH**/ ?>